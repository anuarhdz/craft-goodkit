-- MySQL dump 10.13  Distrib 8.0.33, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vyywgkqbyppodzawylcwxzdxmaqzddfgdlzt` (`primaryOwnerId`),
  CONSTRAINT `fk_fimxswadaklcwbqapgfkggdeegggdgalogcg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vyywgkqbyppodzawylcwxzdxmaqzddfgdlzt` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_phnyuxfkuaikdcgfeosbmavocxengmmfwkix` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_pojggmamzxswekozccwuxgivlfbxwjaqhiin` (`dateRead`),
  KEY `fk_rpekfqsiczscbbcqwacspzxnexzpnardduot` (`pluginId`),
  CONSTRAINT `fk_rpekfqsiczscbbcqwacspzxnexzpnardduot` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wwqebljtvvvjratqtmryikfewrpxnfeoxyrb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dooxjkjuhxpzflirpzatihtmurhbqvelskbl` (`sessionId`,`volumeId`),
  KEY `idx_qhxixsqtkxfpujtxsjhonmfysdprdkyxqppq` (`volumeId`),
  CONSTRAINT `fk_bxckbqhfrbgposczmxoeqpynxpefxbgejwec` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ybyetydltcwslihkrscjjxlzugdwhjkxllfj` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ycbggmydqkjpvqvppixsfmgkwhiritybxeyw` (`filename`,`folderId`),
  KEY `idx_klkmrqacfvwvkvihjnwvbucfrbxydjzszvbh` (`folderId`),
  KEY `idx_ekqspheguchjlyfhiiipkrcgfemhvytwjqgz` (`volumeId`),
  KEY `fk_pwbedumfhpecezdxaqfiyebpxcpgsilalucr` (`uploaderId`),
  CONSTRAINT `fk_dblcnhhpjslwkdifekweyncrqamijvuuymqa` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_plcrfoubxrdopznitnyycmlvhnyfoylvmvuj` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pwbedumfhpecezdxaqfiyebpxcpgsilalucr` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yifxgdljkissftrbxpnbubhrrxssnvpfiztj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_pmfmwgmqqisnczvwjzflixtxaokozoudfmkl` (`siteId`),
  CONSTRAINT `fk_pmfmwgmqqisnczvwjzflixtxaokozoudfmkl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yytuovjuykwotdfcqdetfqefljkbqbcbwzdy` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_zvkeltzciituvvffvdosksqciwfqusbroopz` (`userId`),
  CONSTRAINT `fk_zvkeltzciituvvffvdosksqciwfqusbroopz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pytydmipwjdklnfakkddtzkiainjqwljhadb` (`groupId`),
  KEY `fk_atjvnmpoticsgjwsjuraasuypnlqagvcjfdj` (`parentId`),
  CONSTRAINT `fk_atjvnmpoticsgjwsjuraasuypnlqagvcjfdj` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hyjxdaodwdeoryfvmjkipchmrvmkpfaofvbw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_scxcslsnuwlvunsplvuhtadcgbcapjmjfqey` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qlctuilrdurtkshjqigwtrqcrzoowxcmpftf` (`name`),
  KEY `idx_rryvzjlukfkcnytcsukgvikfujpkrhwlmkwg` (`handle`),
  KEY `idx_pvunxsspmqicicplbqglnfhlwudubuzielpx` (`structureId`),
  KEY `idx_gcexmsebqltefvypxqayguwnyfidbxultuvm` (`fieldLayoutId`),
  KEY `idx_kiycdahrcbtyruuunkhapmawrkluciccwxje` (`dateDeleted`),
  CONSTRAINT `fk_gdyjaclbbgzwhwuyvnmnzurtqorwnkbesgdw` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rnjmohllbhshcqajzglpyxsybkqccooefmwa` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zazmqrylvinimmkvnmkrvgytqktuinfgegcc` (`groupId`,`siteId`),
  KEY `idx_qpeuslkmngunxafriuzswkbiwavihwsjcwjp` (`siteId`),
  CONSTRAINT `fk_qfkriefeohvovhimlkxjrxghgkhfbaahocfd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_taelrdsfmedaletrzeokhcxtslastlyjavks` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_szqsadvprztoiacdffgiqmjjkrzxsurkhmea` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ijlftblycywsqmiznmlmbammoykzxjzgfgle` (`siteId`),
  KEY `fk_bzukigiecxofqkjpvefofxpipeqccqafqruo` (`userId`),
  CONSTRAINT `fk_bzukigiecxofqkjpvefofxpipeqccqafqruo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_fnbadzgxmywarcqirrrgaiwamvcjvsbvufiu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ijlftblycywsqmiznmlmbammoykzxjzgfgle` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_wwjcjwvpjgizrxuipfdwvwufgqaonadxuwsj` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_moxhmhrrrfnopbwjrevtrfifndovnttramwe` (`siteId`),
  KEY `fk_qlasecnvyvhkysfymhieeglcjdeqbkwjrnla` (`fieldId`),
  KEY `fk_teshwfcxmwmvobvzgddxnaampwuejzhjgoer` (`userId`),
  CONSTRAINT `fk_moxhmhrrrfnopbwjrevtrfifndovnttramwe` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qlasecnvyvhkysfymhieeglcjdeqbkwjrnla` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_teshwfcxmwmvobvzgddxnaampwuejzhjgoer` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_uhrdtgznjwpgtdzkbaaqhkugbtxtqnqpqaco` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_aytvefldfayqsdoyganlyauesfewadmilozw` (`userId`),
  CONSTRAINT `fk_aytvefldfayqsdoyganlyauesfewadmilozw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yyikaciqzvfptfxxeqguscrmdplwtlxxfxjy` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_iyxasfoantlqfcwomikwztexipyixgxztdej` (`creatorId`,`provisional`),
  KEY `idx_olhcyhsfgsmfgwivndmpbjteiwgioqxzmdix` (`saved`),
  KEY `fk_riqoamlwxshtaaeinefpwikxpynpceedarth` (`canonicalId`),
  CONSTRAINT `fk_ikoyoeuyacbypvmzbcfkpqtqnfkpgfizqoez` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_riqoamlwxshtaaeinefpwikxpynpceedarth` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_rhwyzxwccavyskxgqchvzntjsydjsxuuyhvg` (`elementId`,`timestamp`,`userId`),
  KEY `fk_ggecnslkjrctmiczyoghqbxbswhgkraxfgcs` (`userId`),
  KEY `fk_ungomzhrlwhwcagdvyiefumhilrgepowxtjf` (`siteId`),
  KEY `fk_cqeklyxktohdywijdyfrceragqwqbshfbakq` (`draftId`),
  CONSTRAINT `fk_cqeklyxktohdywijdyfrceragqwqbshfbakq` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cqmxhecjcqbciugkkleiajhaxkrloglmwpro` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ggecnslkjrctmiczyoghqbxbswhgkraxfgcs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ungomzhrlwhwcagdvyiefumhilrgepowxtjf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qqzrxuygnihijgnainlvqhnoraqtvxayvony` (`dateDeleted`),
  KEY `idx_ltshleaagsszemfvihppkkcejiwhybmwjtla` (`fieldLayoutId`),
  KEY `idx_ilmcebedmwnytfqafypnusjejxwiiquihkbp` (`type`),
  KEY `idx_ttxnylnvfvosovntqgsutzllxmygfbbwljed` (`enabled`),
  KEY `idx_bqtrkdfnyxrxjsamgdujsfmiybxzxiapyior` (`canonicalId`),
  KEY `idx_zmuhflxnfnrnvcdcmdzbjhbfejxmtuunybhc` (`archived`,`dateCreated`),
  KEY `idx_bgbyxfipnrdloeptwjeauhlnuhymgexohwpz` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_npeiwddgnseizbcffqwcvcwxcytilikobcwh` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_gopffhfsiakgtavjhhuvqarxnacxzdmbgvwg` (`draftId`),
  KEY `fk_tfkobkxgdpfqbtayeplsxkednxlyxozfjzyz` (`revisionId`),
  CONSTRAINT `fk_gopffhfsiakgtavjhhuvqarxnacxzdmbgvwg` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_onyjbswzbtqspszbvynxckmahakkrsqqdwil` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tfkobkxgdpfqbtayeplsxkednxlyxozfjzyz` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vmckergnhaodhcsofarkjeltairapufoizen` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-04-07 10:44:46','2024-04-07 10:44:46',NULL,NULL,NULL,'01935cc4-3778-4b99-8a94-33cc44d77237');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_pezqaibzqlmzxkapovbmsmojoonvzutplphg` (`timestamp`),
  CONSTRAINT `fk_gnacguazpmrgahtfruztvoouoahyojcafwvi` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_dhgrofszljqnsmubmtqzrzudnqmywqpsdbow` (`ownerId`),
  CONSTRAINT `fk_dhgrofszljqnsmubmtqzrzudnqmywqpsdbow` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gmccaeuftwvchuskfdnjiqdnsvipqfyxtwoj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xilbxxnjhvgmvfjbanxrtzupxftuamhzbiie` (`elementId`,`siteId`),
  KEY `idx_jnsihktyzdaujaglekqtnvcheihrkmwoteao` (`siteId`),
  KEY `idx_qztuwlfxxqeudlmlfchmfkmawzelayoyvvah` (`title`,`siteId`),
  KEY `idx_gnexivvknybkdpqjcomdkoulhagbfhhkacfr` (`slug`,`siteId`),
  KEY `idx_drdpqyddhjqlejlouopjvmqgcxneqgaazzub` (`enabled`),
  KEY `idx_hglfiwzaxmfhgdencqaqbcniacmdrpnnipdn` (`uri`,`siteId`),
  CONSTRAINT `fk_fpfjbdxgfkizgjvouwftddjqiahhntubpcps` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_otkkwlgqquhmjbauvgujsymrtfrmkbzvsonx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-04-07 10:44:46','2024-04-07 10:44:46','786d7627-7234-4b43-8af0-94c425d54601');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_thmfphxxxffcbhjsfcmpuorxwtrkyceieydj` (`postDate`),
  KEY `idx_nqkekxpxwonurprmxfaomyzujdtbuuxmnuop` (`expiryDate`),
  KEY `idx_wnpuyejqgabhxvkbsznxxtvuuycuypjodkou` (`sectionId`),
  KEY `idx_aewgnvbwleutwztwekhfvxhbcttxywlmqyaz` (`typeId`),
  KEY `idx_tkibhaazofhdinmnhahzsftlerhaclptucbc` (`primaryOwnerId`),
  KEY `idx_rkalnljhvdzykwyblpkalfiturmczqwoxmrn` (`fieldId`),
  KEY `fk_ikfdvwcjadoddyuwfnhwjdrnhxvlkzuafxxr` (`parentId`),
  CONSTRAINT `fk_hksbhzafuvcqrxijpffggevjkqxibqvpymzu` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ighwafrieevsaotblipgbfqatxmceuujukgs` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ihvmautbtmcrumysagkwmszuhbxylsasgjzt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ikfdvwcjadoddyuwfnhwjdrnhxvlkzuafxxr` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_owcylntasmcrcavvmyihxniubobefuumrzun` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zwhbqiirdjthfhjwjknqvkydhgtftdzylhtf` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_rzhnbcrcetdyrbtemkgtuuqvifqeczfkzyok` (`authorId`),
  KEY `idx_ojrcgxbwsarwikksfxmxodvvxgcbtpctyzcn` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_kjjmdjlbagrzbpahrjgcplvnvarvaufljgud` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zqggxvagmnwmpveuqhspsuxatwibdpqzcskh` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_azaqzcginpxsreoyxgkuoimupcltfomiksuq` (`fieldLayoutId`),
  KEY `idx_eettzcwrnessyywcabaqvafarbkxirdcqqyp` (`dateDeleted`),
  CONSTRAINT `fk_juroglzptjqfaieygpsmtgrbinbgohxlbjfw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ndnqmzscwejmdvxlduirsigccupiultdriue` (`dateDeleted`),
  KEY `idx_dnoptmzrthewmtqzloakzdjayzqfsvhwgani` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"80921c9c-4c67-4baa-b360-9e7116fbc99c\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"e5cc945a-b76e-4404-907a-d561cdb401bd\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"f986dd6b-b574-407c-8891-ba429a509c9a\", \"cols\": null, \"name\": null, \"rows\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"alt\", \"requirable\": true, \"orientation\": null, \"placeholder\": null, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-07 10:59:51','2024-04-07 11:01:12',NULL,'cd1a357a-792b-4c23-b77f-0b5ed54f1776'),(2,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"410e623a-8ff1-49ad-a1fc-340ef2e0499f\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"787c4b98-838d-45e0-ba85-6cceebf89331\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"784d96dd-30ed-44c3-a627-aba5eb325995\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"e2883553-ca03-48ee-865e-a78933ec0067\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-04-07 11:02:25','2024-04-07 11:02:25',NULL,'c5ff46d9-2d8c-4a9f-9f96-d87615971618');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xwyigooivpwiocpjpwwqtrbmfytovhsfwcmm` (`handle`,`context`),
  KEY `idx_xcrrkxklsjahkxvnewobhihdaqbscyykjhrf` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Caption','caption','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-04-07 11:02:20','2024-04-07 11:02:20','e2883553-ca03-48ee-865e-a78933ec0067');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jjrworhfyfxxvhcurmemesrnjkvzdvxtpycn` (`name`),
  KEY `idx_fcobsfizrqcwrdafergiukihuezgkgpuneyb` (`handle`),
  KEY `idx_clraschqxaplysjbpccpwbvujovoyzjzhpnr` (`fieldLayoutId`),
  KEY `idx_ijrkimhobayiymocuzpblgkvkmnxkdvcnaea` (`sortOrder`),
  CONSTRAINT `fk_myblcsvsvtzonpuzardtthwrknjiynqmvnsx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vihtxmfpdttynmndfjrmuinwoscutfbirjvb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pxdytrkfajuownpqfbnkcjutahvtmpsplwmr` (`accessToken`),
  UNIQUE KEY `idx_kwkrioacxdqsdzfzvolxrsbwbehtvxknxdet` (`name`),
  KEY `fk_bisyesrubklxhvatqldwmwjlamvoaneuismf` (`schemaId`),
  CONSTRAINT `fk_bisyesrubklxhvatqldwmwjlamvoaneuismf` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hyper_element_cache`
--

DROP TABLE IF EXISTS `hyper_element_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hyper_element_cache` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int DEFAULT NULL,
  `sourceId` int DEFAULT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `sourceType` varchar(255) DEFAULT NULL,
  `targetId` int DEFAULT NULL,
  `targetSiteId` int DEFAULT NULL,
  `targetType` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gsfbzbzryycdfpbtmcviljbvgjnhpopzbdgw` (`id`),
  KEY `idx_refyvnrqjazpoluwmkrkqyojgtqjnrbnpzey` (`sourceId`),
  KEY `idx_zsoignbtwfmfqqbzljfbihoauzjiwlketqdi` (`sourceSiteId`),
  KEY `idx_ppndqmihzsdrijzougivsmgtlfpqzskkywbd` (`targetId`),
  KEY `idx_mtflizutlyoiutumfivwojfpizwqjbcbvcib` (`targetSiteId`),
  CONSTRAINT `fk_nqozxprmevebxfeinjosjqrtcntzdpszoxbr` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_otgwhzmblrgnyggoygxrgpcbsboflzbkpxtk` FOREIGN KEY (`targetSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbxtdxivpbdocgdifkwtfsybeqiusxjnbawn` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ubtgrzlgwnsdlkfjivjvplwwmcmhghfovjqd` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hyper_element_cache`
--

LOCK TABLES `hyper_element_cache` WRITE;
/*!40000 ALTER TABLE `hyper_element_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `hyper_element_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hyper_field_cache`
--

DROP TABLE IF EXISTS `hyper_field_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hyper_field_cache` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sourceField` char(36) NOT NULL DEFAULT '0',
  `targetField` char(36) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aqcodhkfuwtjxffuwltqnbbyucvbnhfmactk` (`id`),
  KEY `idx_tohneilwgdslaocnhgkvnzzryifowgsoxlxh` (`sourceField`),
  KEY `idx_pocrzjigitusyrwcsgrtuwgyegqgrzidgqnp` (`targetField`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hyper_field_cache`
--

LOCK TABLES `hyper_field_cache` WRITE;
/*!40000 ALTER TABLE `hyper_field_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `hyper_field_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vnxkhxdacvuhkagdotvvvtouqynkxcpcimdu` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_khxdlhuygivtnggiqluemzzfwoctbxvtucsk` (`name`),
  KEY `idx_xakaepqlaihqussjcbovoaxguwlqdxwzpatr` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.0.2','5.0.0.20',0,'xysgpbqrlipx','3@pfsjuytdgy','2024-04-07 10:44:46','2024-04-08 01:00:30','f4867ef3-541e-4e2c-9c25-a261e3f6655c');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lucxielfupnbkmnbrwgqmpbdmamxbibhfjtv` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','3bf68ea4-9853-44be-bd4f-abdc63be8423'),(2,'craft','m221101_115859_create_entries_authors_table','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','4b22c644-0613-4780-ae59-1443bfc55620'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','019dc4c4-a7b4-4e47-9744-f0dd40d5e0fc'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','a637562f-be7e-489a-858d-01fa5ffdca44'),(5,'craft','m230314_110309_add_authenticator_table','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','ddf38483-67ae-4b76-b39d-24b3ddb8b0c6'),(6,'craft','m230314_111234_add_webauthn_table','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','e54671c2-dd30-4f2a-b2ad-2c84082e08b5'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','ac12221b-6dac-455b-a903-bafd1c0c338e'),(8,'craft','m230511_000000_field_layout_configs','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','a0ab8004-abe8-49ae-8df4-c091ce264fdf'),(9,'craft','m230511_215903_content_refactor','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','d67ce2ab-42d4-4ed4-adb8-41be7c4242de'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','ff82c4ec-573c-4d96-b604-307c6deaf7eb'),(11,'craft','m230524_000001_entry_type_icons','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','37b41a29-a011-4709-b9d1-1b4e3fafa057'),(12,'craft','m230524_000002_entry_type_colors','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','275db8ee-158f-4c74-a21c-03d45e887a0b'),(13,'craft','m230524_220029_global_entry_types','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','10f352f4-1559-48d0-98d1-cb7b8e9218fc'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','91214011-9f83-4e85-9ada-c3574384ad49'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','21956fb3-d18b-4028-8179-952de089abfc'),(16,'craft','m230616_173810_kill_field_groups','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','8ba955e5-9b12-441d-b837-8b770febcc15'),(17,'craft','m230616_183820_remove_field_name_limit','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','31871e52-3454-4a56-944e-a2aded9e1ff5'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','8c1a72db-45e8-41c1-b7f7-4d41d942f594'),(19,'craft','m230710_162700_element_activity','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','60079fb9-b3ae-4743-9fd7-73494d09ba5a'),(20,'craft','m230820_162023_fix_cache_id_type','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','b3012cc4-6cd4-4ca1-b24a-4f1e9a75a595'),(21,'craft','m230826_094050_fix_session_id_type','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','f61ce9f9-8b5a-4270-bfae-ca4a8375ab6d'),(22,'craft','m230904_190356_address_fields','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','d8c39184-73ed-427b-8050-96ee82bca292'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','fd8d51e5-718a-4f51-81c5-05b3fcb6bc20'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','31e1575e-3783-47bd-b399-739139c25314'),(25,'craft','m231213_030600_element_bulk_ops','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','99c36175-2d99-48c2-8e87-630f65d1e33c'),(26,'craft','m240129_150719_sites_language_amend_length','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','d1643218-cb56-44b3-b54e-b801a0c9c547'),(27,'craft','m240206_035135_convert_json_columns','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','3c9ca614-68b2-43cd-92d9-49bdb11fa141'),(28,'craft','m240207_182452_address_line_3','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','34c62e86-dc5e-44f5-8508-5f6473eb5df3'),(29,'craft','m240302_212719_solo_preview_targets','2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 10:44:47','5ff3ee3b-4565-4dd9-ac18-a5d53216e113'),(30,'plugin:ckeditor','Install','2024-04-07 10:57:05','2024-04-07 10:57:05','2024-04-07 10:57:05','eebb38c7-2872-4047-8330-f9df58a7a9ef'),(31,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-04-07 10:57:05','2024-04-07 10:57:05','2024-04-07 10:57:05','9c72b266-b825-4ca5-b10f-1f7f51cdecd7'),(32,'plugin:hyper','Install','2024-04-07 10:57:06','2024-04-07 10:57:06','2024-04-07 10:57:06','a270001c-8ab6-46fb-8dc2-16c68b087313'),(33,'plugin:navigation','Install','2024-04-07 10:57:07','2024-04-07 10:57:07','2024-04-07 10:57:07','ca8773ba-5db9-4cb1-b5fe-460290402846'),(34,'plugin:navigation','m231229_000000_content_refactor','2024-04-07 10:57:07','2024-04-07 10:57:07','2024-04-07 10:57:07','dd24ef45-21e5-46af-a637-e86e32c40e5e'),(35,'plugin:seomatic','Install','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','3f6f4742-0f22-4c7e-9292-b7e6888fe147'),(36,'plugin:seomatic','m180314_002755_field_type','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','a5db896b-2fcb-4fc1-a072-d2147b5f8e18'),(37,'plugin:seomatic','m180314_002756_base_install','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','8f272e5a-bcf3-4e2e-a04c-a45b9e2fe97d'),(38,'plugin:seomatic','m180502_202319_remove_field_metabundles','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','02456b07-bc55-4498-92ea-0d354df8a1ae'),(39,'plugin:seomatic','m180711_024947_commerce_products','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','88de44b3-c05e-4633-aa1c-9591cd8143d4'),(40,'plugin:seomatic','m190401_220828_longer_handles','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','c8974d51-3728-42e0-9235-14609ed78602'),(41,'plugin:seomatic','m190518_030221_calendar_events','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','b53c4d6c-5489-4dd2-9733-1f29ca647df1'),(42,'plugin:seomatic','m200419_203444_add_type_id','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','c1182a9f-baa9-4c05-a29c-89f8e90321a6'),(43,'plugin:seomatic','m210603_213100_add_gql_schema_components','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','cd48b8c3-72e4-4a57-96f2-6974432adeb7'),(44,'plugin:seomatic','m210817_230853_announcement_v3_4','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','2e50683a-7bc9-4eb6-afef-2cf8284ca45e'),(45,'plugin:seomatic','m230601_184259_announcement_google_ua_deprecated','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','1f15681b-6d35-4842-a663-0ad5fad69687');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_navs`
--

DROP TABLE IF EXISTS `navigation_navs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_navs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `instructions` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `maxNodes` int DEFAULT NULL,
  `maxNodesSettings` text,
  `permissions` text,
  `fieldLayoutId` int DEFAULT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cqiojvdhdydffuwkmokjbvlycxzqzmikjhcf` (`handle`),
  KEY `idx_igjnxmyjzlimywqdthvqpjftoswezoiyuhab` (`structureId`),
  KEY `idx_xiztploktfcmxvuocyuxyeherrngdibcypig` (`fieldLayoutId`),
  KEY `idx_qpqzqhpmndincuhhjegddkuxpdasiuuyaihg` (`dateDeleted`),
  CONSTRAINT `fk_iuvtlrziitwmqdpdvdghhqjzeyqysujngnjk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_taabcbwyssghjgbpbrtjmowkqaacjncfquzp` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_navs`
--

LOCK TABLES `navigation_navs` WRITE;
/*!40000 ALTER TABLE `navigation_navs` DISABLE KEYS */;
/*!40000 ALTER TABLE `navigation_navs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_navs_sites`
--

DROP TABLE IF EXISTS `navigation_navs_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_navs_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `navId` int NOT NULL,
  `siteId` int NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rajtkzgldedkdzsfwysyknotpypaqzhmllsj` (`navId`,`siteId`),
  KEY `idx_obqgiihifftilamimbrlepdddppubmnrdoyn` (`siteId`),
  CONSTRAINT `fk_vfhdidifbbuhxdxgfkxoechuhdynaoytwhvu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wfykokgpzrbmaijzjeuqbcvdzqjzttmhaumq` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_navs_sites`
--

LOCK TABLES `navigation_navs_sites` WRITE;
/*!40000 ALTER TABLE `navigation_navs_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `navigation_navs_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_nodes`
--

DROP TABLE IF EXISTS `navigation_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_nodes` (
  `id` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `navId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `classes` varchar(255) DEFAULT NULL,
  `urlSuffix` varchar(255) DEFAULT NULL,
  `customAttributes` text,
  `data` text,
  `newWindow` tinyint(1) DEFAULT '0',
  `deletedWithNav` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ahqskqyjmfqwbjdazjqwswfpnnsrpnnynyxa` (`navId`),
  KEY `fk_cabbkatdcnmjvnbvwndsjrcjzthdfdpfidmx` (`elementId`),
  CONSTRAINT `fk_cabbkatdcnmjvnbvwndsjrcjzthdfdpfidmx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tqoucsbeqqdkkxvdeqktxnrnsdovxcheqmwh` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wpyvurpmxlkizqwqdlntmhxedktvjasqfdqx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_nodes`
--

LOCK TABLES `navigation_nodes` WRITE;
/*!40000 ALTER TABLE `navigation_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `navigation_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tfyqcslcqrjspmeajxjyyrvknwhsnzmtbkbu` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'ckeditor','4.0.3','3.0.0.0','2024-04-07 10:57:05','2024-04-07 10:57:05','2024-04-07 10:57:05','f900dc4f-edeb-442a-9163-04454c3e76cc'),(2,'hyper','2.0.0-beta.7','1.0.0','2024-04-07 10:57:06','2024-04-07 10:57:06','2024-04-07 10:57:06','98a4958d-92bb-49ad-8d13-12755ed0777c'),(3,'navigation','3.0.0-beta.2','2.1.0','2024-04-07 10:57:07','2024-04-07 10:57:07','2024-04-07 10:57:07','8498e8c3-ebfc-4a0d-abd5-3ec2ee0055ed'),(4,'query','3.1.0','1.0.0','2024-04-07 10:57:09','2024-04-07 10:57:09','2024-04-07 10:57:09','b0265c43-a11e-4286-9d52-3dc1e95a4a9c'),(5,'splashing-images','5.0.3','1.2.0','2024-04-07 10:57:27','2024-04-07 10:57:27','2024-04-07 10:57:27','d2610270-e3a9-464d-ba2c-bcb2fc2551ca'),(6,'vite','5.0.0-beta.3','1.0.0','2024-04-07 11:02:48','2024-04-07 11:02:48','2024-04-07 11:02:48','4c207e69-d74b-419f-92c3-8d9ba4f65ae0'),(7,'seomatic','5.0.0-beta.8','3.0.12','2024-04-07 11:04:34','2024-04-07 11:04:34','2024-04-07 11:04:34','3c102fd4-d567-4879-ae48-1d55a5133e97');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.headingLevels.0','1'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.headingLevels.1','2'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.headingLevels.2','3'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.headingLevels.3','4'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.headingLevels.4','5'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.headingLevels.5','6'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.name','\"Simple\"'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.toolbar.0','\"heading\"'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.toolbar.1','\"|\"'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.toolbar.2','\"bold\"'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.toolbar.3','\"italic\"'),('ckeditor.configs.391346c0-6543-451a-a3a5-9529fac63e3f.toolbar.4','\"link\"'),('dateModified','1712538030'),('email.fromEmail','\"anuar@hey.com\"'),('email.fromName','\"CraftCMS Goodkit\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.columnSuffix','null'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.handle','\"caption\"'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.instructions','null'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.name','\"Caption\"'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.searchable','false'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.settings.byteLimit','null'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.settings.charLimit','null'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.settings.code','false'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.settings.initialRows','4'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.settings.multiline','false'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.settings.placeholder','null'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.settings.uiMode','\"normal\"'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.translationKeyFormat','null'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.translationMethod','\"none\"'),('fields.e2883553-ca03-48ee-865e-a78933ec0067.type','\"craft\\\\fields\\\\PlainText\"'),('fs.mediaImages.hasUrls','true'),('fs.mediaImages.name','\"Media Images\"'),('fs.mediaImages.settings.path','\"@filesystemPath/images\"'),('fs.mediaImages.type','\"craft\\\\fs\\\\Local\"'),('fs.mediaImages.url','\"@filesystemUrl/images\"'),('fs.mediaVideos.hasUrls','true'),('fs.mediaVideos.name','\"Media Videos\"'),('fs.mediaVideos.settings.path','\"@filesystemPath/videos\"'),('fs.mediaVideos.type','\"craft\\\\fs\\\\Local\"'),('fs.mediaVideos.url','\"@filesystemUrl/videos\"'),('meta.__names__.12b1eba7-eba9-4a9d-b427-47a4b9951704','\"Goodkit\"'),('meta.__names__.391346c0-6543-451a-a3a5-9529fac63e3f','\"Simple\"'),('meta.__names__.6c8dfb37-039b-487a-8d0a-8339c35857d7','\"Goodkit\"'),('meta.__names__.a23bbdd9-a1f0-45c6-abe2-23554ce14258','\"Videos\"'),('meta.__names__.db778210-0abd-4ebf-a5a5-e90e9735dfd6','\"Images\"'),('meta.__names__.e2883553-ca03-48ee-865e-a78933ec0067','\"Caption\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.hyper.edition','\"standard\"'),('plugins.hyper.enabled','true'),('plugins.hyper.licenseKey','\"ITMQCLCKO54QZKRXOBUS6RZJ\"'),('plugins.hyper.schemaVersion','\"1.0.0\"'),('plugins.navigation.edition','\"standard\"'),('plugins.navigation.enabled','true'),('plugins.navigation.licenseKey','\"VYJ1I9S1IFXETM0XCZ8O2D5G\"'),('plugins.navigation.schemaVersion','\"2.1.0\"'),('plugins.query.edition','\"standard\"'),('plugins.query.enabled','true'),('plugins.query.schemaVersion','\"1.0.0\"'),('plugins.seomatic.edition','\"standard\"'),('plugins.seomatic.enabled','true'),('plugins.seomatic.licenseKey','\"VGLEPE3J9JMEZSTIF1R7B9SN\"'),('plugins.seomatic.schemaVersion','\"3.0.12\"'),('plugins.splashing-images.edition','\"standard\"'),('plugins.splashing-images.enabled','true'),('plugins.splashing-images.schemaVersion','\"1.2.0\"'),('plugins.splashing-images.settings.destination','\"1\"'),('plugins.splashing-images.settings.folder','\"unsplash\"'),('plugins.splashing-images.settings.pluginLabel','\"Unsplash\"'),('plugins.vite.edition','\"standard\"'),('plugins.vite.enabled','true'),('plugins.vite.schemaVersion','\"1.0.0\"'),('siteGroups.12b1eba7-eba9-4a9d-b427-47a4b9951704.name','\"Goodkit\"'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.baseUrl','\"@web\"'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.enabled','true'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.handle','\"default\"'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.hasUrls','true'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.language','\"en-US\"'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.name','\"Goodkit\"'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.primary','true'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.siteGroup','\"12b1eba7-eba9-4a9d-b427-47a4b9951704\"'),('sites.6c8dfb37-039b-487a-8d0a-8339c35857d7.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Goodkit\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.0.0.20\"'),('system.timeZone','\"America/Mexico_City\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.altTranslationKeyFormat','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.altTranslationMethod','\"none\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elementCondition','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.autocapitalize','true'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.autocomplete','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.autocorrect','true'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.class','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.disabled','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.elementCondition','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.id','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.includeInCards','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.inputType','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.instructions','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.label','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.max','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.min','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.name','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.orientation','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.placeholder','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.providesThumbs','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.readonly','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.requirable','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.size','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.step','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.tip','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.title','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.uid','\"787c4b98-838d-45e0-ba85-6cceebf89331\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.userCondition','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.warning','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.0.width','100'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.elementCondition','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.fieldUid','\"e2883553-ca03-48ee-865e-a78933ec0067\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.handle','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.includeInCards','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.instructions','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.label','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.providesThumbs','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.required','false'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.tip','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.uid','\"784d96dd-30ed-44c3-a627-aba5eb325995\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.userCondition','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.warning','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.elements.1.width','100'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.name','\"Content\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.uid','\"410e623a-8ff1-49ad-a1fc-340ef2e0499f\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fieldLayouts.c5ff46d9-2d8c-4a9f-9f96-d87615971618.tabs.0.userCondition','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.fs','\"mediaVideos\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.handle','\"videos\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.name','\"Videos\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.sortOrder','2'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.subpath','\"\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.titleTranslationKeyFormat','null'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.titleTranslationMethod','\"site\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.transformFs','\"\"'),('volumes.a23bbdd9-a1f0-45c6-abe2-23554ce14258.transformSubpath','\"\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.altTranslationKeyFormat','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.altTranslationMethod','\"none\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elementCondition','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.autocapitalize','true'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.autocomplete','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.autocorrect','true'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.class','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.disabled','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.elementCondition','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.id','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.includeInCards','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.inputType','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.instructions','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.label','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.max','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.min','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.name','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.orientation','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.placeholder','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.providesThumbs','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.readonly','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.requirable','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.size','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.step','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.tip','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.title','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.uid','\"e5cc945a-b76e-4404-907a-d561cdb401bd\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.userCondition','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.warning','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.0.width','100'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.attribute','\"alt\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.class','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.cols','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.disabled','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.elementCondition','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.id','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.includeInCards','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.instructions','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.label','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.name','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.orientation','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.placeholder','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.providesThumbs','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.readonly','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.requirable','true'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.required','false'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.rows','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.tip','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.title','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.uid','\"f986dd6b-b574-407c-8891-ba429a509c9a\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.userCondition','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.warning','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.elements.1.width','100'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.name','\"Content\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.uid','\"80921c9c-4c67-4baa-b360-9e7116fbc99c\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fieldLayouts.cd1a357a-792b-4c23-b77f-0b5ed54f1776.tabs.0.userCondition','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.fs','\"mediaImages\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.handle','\"images\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.name','\"Images\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.sortOrder','1'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.subpath','\"\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.titleTranslationKeyFormat','null'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.titleTranslationMethod','\"site\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.transformFs','\"\"'),('volumes.db778210-0abd-4ebf-a5a5-e90e9735dfd6.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_fvjqqkakqawiapnliqdjfolovfsngbzqbiwh` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_etxrjsowkcurinqhvljfughykbvpppaqpwgw` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vtugqpwpclixbismooyuykozgbnkyvvvgizk` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_jfeglfgysifyqiizuztfudztrhcxxqcbfwpt` (`sourceId`),
  KEY `idx_dvjlbullthuzunshncplelgfdyvolqkeahkj` (`targetId`),
  KEY `idx_rzbjxyjkokuzrpgczkhfxtpaovzhhkkblizi` (`sourceSiteId`),
  CONSTRAINT `fk_amiozzxyndancgvsdffofngghzfjpzuwamrq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_djpgoehmvcsecmtlzhzqdhgoyeiwyrfwyqhw` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ybbztxumfqksvyklnihqnuexfaorbdbbarhz` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('1a261136','@craft/query/assets'),('2819cc9c','@craft/web/assets/plugins/dist'),('2e9860d1','@craft/web/assets/vue/dist'),('35bd3763','@craft/web/assets/feed/dist'),('37460e3','@craft/web/assets/picturefill/dist'),('3ab8b88a','@craft/web/assets/velocity/dist'),('3f2fba3d','@craft/web/assets/jquerypayment/dist'),('3f7c655f','@craft/web/assets/jquerytouchevents/dist'),('4cfe11a8','@craft/web/assets/dashboard/dist'),('58289327','@craft/web/assets/htmx/dist'),('59b8cbd1','@nystudio107/seomatic/web/assets/dist'),('636681e3','@craft/web/assets/jqueryui/dist'),('698111f5','@bower/jquery/dist'),('6c610e1d','@craft/web/assets/elementresizedetector/dist'),('752f4efe','@craft/web/assets/updates/dist'),('76957421','@craft/web/assets/prismjs/dist'),('7d1d5748','@craft/web/assets/fileupload/dist'),('8b4b2b19','@craft/web/assets/axios/dist'),('8ccdde3','@craft/web/assets/xregexp/dist'),('9039d614','@craft/web/assets/conditionbuilder/dist'),('93bebe40','@craft/web/assets/recententries/dist'),('a047df77','@craft/web/assets/fieldsettings/dist'),('a42ba875','@craft/web/assets/generalsettings/dist'),('a62e0a41','@craft/web/assets/iframeresizer/dist'),('aa80a27','@craft/web/assets/craftsupport/dist'),('ad04fc2e','@craft/web/assets/updateswidget/dist'),('ad4f03f6','@craft/web/assets/d3/dist'),('b77a25bf','@craft/web/assets/cp/dist'),('ba067e69','@craft/web/assets/installer/dist'),('bb3287f7','@craft/web/assets/selectize/dist'),('bc273dd5','@craft/web/assets/tailwindreset/dist'),('be0115c2','@craft/web/assets/pluginstore/dist'),('c49effa3','@craft/web/assets/admintable/dist'),('cd3c1f6f','@craft/web/assets/passkeysetup/dist'),('d510bc5c','@craft/web/assets/garnish/dist'),('ed881d75','@craft/web/assets/utilities/dist'),('f3508f56','@craft/web/assets/sites/dist'),('fda28b4b','@craft/web/assets/fabric/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jrjjzdtiwwrpdoteablnotbersiwutouudsj` (`canonicalId`,`num`),
  KEY `fk_lmpuiuoqsigsowyxhettwqklzdsteinwmffc` (`creatorId`),
  CONSTRAINT `fk_lmpuiuoqsigsowyxhettwqklzdsteinwmffc` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pcociogytedukbqdnvsvexjwpfkbxvypmypi` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_zhtrtopducwtsuggqcxnaegcjqpcmszxaspm` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' anuar hey com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin kit ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hnxfyzzngcusmlvkdkqzefgsytcmaudkxxab` (`handle`),
  KEY `idx_dltfxnweeozdrzpkjoehiiahfyevuhqeqpqk` (`name`),
  KEY `idx_ansnhgqnfpqparloyrcbtqunwqdawlbtkbki` (`structureId`),
  KEY `idx_hqvesyeggsedodnzznzdyfpevrkkfoogstmg` (`dateDeleted`),
  CONSTRAINT `fk_fzpdxhcbiigusvnflisbpmffngtcdpuohqlj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_vwjdjqjjywyufssuwwlloitbyvoemsgtrgae` (`typeId`),
  CONSTRAINT `fk_clonvkfbaaufuxgerqdpdtrgqncjdubdvyzh` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vwjdjqjjywyufssuwwlloitbyvoemsgtrgae` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bfkvilgxbqsuiqauudnwkpxxqcdhafgwrjmc` (`sectionId`,`siteId`),
  KEY `idx_rmdqgervctpouskdovstdklqkpbiczvhrqwv` (`siteId`),
  CONSTRAINT `fk_vbjrafohangaanndpbhzuavijevyimmrudsm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vdufbubfujqzqyujqolypzehcrwdxyjakhzn` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seomatic_metabundles`
--

DROP TABLE IF EXISTS `seomatic_metabundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seomatic_metabundles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `bundleVersion` varchar(255) NOT NULL DEFAULT '',
  `sourceBundleType` varchar(255) NOT NULL DEFAULT '',
  `sourceId` int DEFAULT NULL,
  `sourceName` varchar(255) NOT NULL DEFAULT '',
  `sourceHandle` varchar(255) NOT NULL DEFAULT '',
  `sourceType` varchar(64) NOT NULL DEFAULT '',
  `typeId` int DEFAULT NULL,
  `sourceTemplate` varchar(500) DEFAULT '',
  `sourceSiteId` int DEFAULT NULL,
  `sourceAltSiteSettings` text,
  `sourceDateUpdated` datetime NOT NULL,
  `metaGlobalVars` text,
  `metaSiteVars` text,
  `metaSitemapVars` text,
  `metaContainers` text,
  `redirectsContainer` text,
  `frontendTemplatesContainer` text,
  `metaBundleSettings` text,
  PRIMARY KEY (`id`),
  KEY `idx_yhpqsbwvzvfjovvcnkhazilcaygqddsfpmga` (`sourceBundleType`),
  KEY `idx_kyoysxbjgadutsueyvrwhmtyjqtpbxkaggxj` (`sourceId`),
  KEY `idx_bilygwbdidczjkdynakcwbwwduqzkanwfxje` (`sourceSiteId`),
  KEY `idx_oxmzljpogbtjnnlwzrwbmoxjaaeswjzjggjv` (`sourceHandle`),
  CONSTRAINT `fk_tkgrnspcoyhoixqnovncujhjgpkwaqpuludt` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seomatic_metabundles`
--

LOCK TABLES `seomatic_metabundles` WRITE;
/*!40000 ALTER TABLE `seomatic_metabundles` DISABLE KEYS */;
INSERT INTO `seomatic_metabundles` VALUES (1,'2024-04-07 11:04:34','2024-04-07 11:04:34','038e67f1-9c59-41a6-90ff-635678bb83dd','1.0.71','__GLOBAL_BUNDLE__',1,'__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__',NULL,'',1,'[]','2024-04-07 11:04:34','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"before\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ seomatic.helper.safeCanonicalUrl() }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.meta.seoImage }}\",\"ogImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"ogImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.meta.seoImage }}\",\"twitterImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"twitterImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"CraftCMS Goodkit\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"newsSitemap\":false,\"newsPublicationName\":\"\",\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]},\"tagAttrs\":[]},\"keywords\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.seoKeywords }}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.seoDescription }}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"referrer\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.referrer }}\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"robots\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.robots }}\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{{ seomatic.meta.robots }}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookProfileId }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookAppId }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:site_name\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.siteName }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:type\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogType }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:url\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.canonicalUrl }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:title\":{\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.ogSiteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogTitle }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogDescription }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImage }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image:width\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageWidth }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:height\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageHeight }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageDescription }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"facebook-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"facebook-domain-verification\",\"property\":null,\"include\":true,\"key\":\"facebook-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"facebookSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterCard }}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{{ seomatic.site.twitterHandle }}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"tagAttrs\":[]},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{{ seomatic.meta.twitterCreator }}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]},\"tagAttrs\":[]},\"twitter:title\":{\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.twitterSiteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterTitle }}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterDescription }}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImage }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageWidth }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageHeight }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageDescription }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":null,\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.googleSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]},\"tagAttrs\":[]},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.bingSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]},\"tagAttrs\":[]},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.pinterestSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.meta.canonicalUrl }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"\\/\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"\\/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text\\/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]},\"tagAttrs\":[]},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.site.googlePublisherLink }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]},\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https:\\/\\/developers.google.com\\/gtagjs\\/)\",\"templatePath\":\"_frontend\\/scripts\\/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"><\\/script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Measurement\\/Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `G-XXXXXXXXXX` or `UA-XXXXXX-XX`, not the entire script code. [Learn More](https:\\/\\/support.google.com\\/analytics\\/answer\\/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.google.com\\/adwords-remarketing-tag\\/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/support.google.com\\/dcm\\/partner\\/answer\\/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/gtagjs\\/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/gtagjs\\/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/gtagjs\\/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.googletagmanager.com\\/gtag\\/js\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https:\\/\\/support.google.com\\/tagmanager\\/answer\\/6102821?hl=en)\",\"templatePath\":\"_frontend\\/scripts\\/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"><\\/iframe><\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.google.com\\/tag-manager\\/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dataLayer\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.googletagmanager.com\\/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.googletagmanager.com\\/ns.html\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https:\\/\\/www.facebook.com\\/business\\/help\\/651294705016616)\",\"templatePath\":\"_frontend\\/scripts\\/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" \\/><\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.facebook.com\\/docs\\/facebook-pixel\\/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/connect.facebook.net\\/en_US\\/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.facebook.com\\/tr\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend\\/scripts\\/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text\\/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text\\/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n<\\/script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" \\/>\\n<\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/www.linkedin.com\\/help\\/lms\\/answer\\/65513\\/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/snap.licdn.com\\/li.lms-analytics\\/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/dc.ads.linkedin.com\\/collect\\/\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text\\/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"><\\/script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/knowledge.hubspot.com\\/articles\\/kcs_article\\/reports\\/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"\\/\\/js.hs-scripts.com\\/\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"pinterestTag\":{\"name\":\"Pinterest Tag\",\"description\":\"The Pinterest tag allows you to track actions people take on your website after viewing your Promoted Pin. You can use this information to measure return on ad spend (RoAS) and create audiences to target on your Promoted Pins. [Learn More](https:\\/\\/help.pinterest.com\\/en\\/business\\/article\\/track-conversions-with-pinterest-tag)\",\"templatePath\":\"_frontend\\/scripts\\/pinterestTagHead.twig\",\"templateString\":\"{% if pinterestTagId.value is defined and pinterestTagId.value %}\\n!function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(\\nArray.prototype.slice.call(arguments))};var\\nn=window.pintrk;n.queue=[],n.version=\\\"3.0\\\";var\\nt=document.createElement(\\\"script\\\");t.async=!0,t.src=e;var\\nr=document.getElementsByTagName(\\\"script\\\")[0];r.parentNode.insertBefore(t,r)}}(\\\"{{ pinterestTagUrl.value }}\\\");\\npintrk(\'load\', \'{{ pinterestTagId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\npintrk(\'page\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend\\/scripts\\/pinterestTagBody.twig\",\"bodyTemplateString\":\"{% if pinterestTagId.value is defined and pinterestTagId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ pinterestTagNoScriptUrl.value }}?tid={{ pinterestTagId.value }}&noscript=1\\\" \\/><\\/noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"pinterestTagId\":{\"title\":\"Pinterest Tag ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https:\\/\\/developers.pinterest.com\\/docs\\/ad-tools\\/conversion-tag\\/)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Pinterest Tag PageView\",\"instructions\":\"Controls whether the Pinterest Tag script automatically sends a PageView to when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"pinterestTagUrl\":{\"title\":\"Pinterest Tag Script URL\",\"instructions\":\"The URL to the Pinterest Tag script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/s.pinimg.com\\/ct\\/core.js\"},\"pinterestTagNoScriptUrl\":{\"title\":\"Pinterest Tag Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Pinterest Tag `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/ct.pinterest.com\\/v3\\/\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"pinterestTag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"fathom\":{\"name\":\"Fathom\",\"description\":\"Fathom is a simple, light-weight, privacy-first alternative to Google Analytics. So, stop scrolling through pages of reports and collecting gobs of personal data about your visitors, both of which you probably don’t need. [Learn More](https:\\/\\/usefathom.com\\/)\",\"templatePath\":\"_frontend\\/scripts\\/fathomAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-site\\\", \\\"{{ siteId.value | raw }}\\\");\\n{% if honorDnt.value %}\\ntag.setAttribute(\\\"data-honor-dnt\\\", \\\"true\\\");\\n{% endif %}\\n{% if disableAutoTracking.value %}\\ntag.setAttribute(\\\"data-auto\\\", \\\"false\\\");\\n{% endif %}\\n{% if ignoreCanonicals.value %}\\ntag.setAttribute(\\\"data-canonical\\\", \\\"false\\\");\\n{% endif %}\\n{% if excludedDomains.value | length %}\\ntag.setAttribute(\\\"data-excluded-domains\\\", \\\"{{ excludedDomains.value | raw }}\\\");\\n{% endif %}\\n{% if includedDomains.value | length %}\\ntag.setAttribute(\\\"data-included-domains\\\", \\\"{{ includedDomains.value | raw }}\\\");\\n{% endif %}\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking)\",\"type\":\"string\",\"value\":\"\"},\"honorDnt\":{\"title\":\"Honoring Do Not Track (DNT)\",\"instructions\":\"By default we track every visitor to your website, regardless of them having DNT turned on or not. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"disableAutoTracking\":{\"title\":\"Disable automatic tracking\",\"instructions\":\"By default, we track a page view every time a visitor to your website loads a page with our script on it. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"ignoreCanonicals\":{\"title\":\"Ignore canonicals\",\"instructions\":\"If there’s a canonical URL in place, then by default we use it instead of the current URL. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"excludedDomains\":{\"title\":\"Excluded Domains\",\"instructions\":\"You exclude one or several domains, so our tracker will track things on every domain, except the ones excluded. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"includedDomains\":{\"title\":\"Included Domains\",\"instructions\":\"If you want to go in the opposite direction and only track stats on a specific domain. [Learn More](https:\\/\\/usefathom.com\\/support\\/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Fathom Script URL\",\"instructions\":\"The URL to the Fathom tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/cdn.usefathom.com\\/script.js\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"fathom\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"matomo\":{\"name\":\"Matomo\",\"description\":\"Matomo is a Google Analytics alternative that protects your data and your customers\' privacy [Learn More](https:\\/\\/matomo.org\\/)\",\"templatePath\":\"_frontend\\/scripts\\/matomoAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value and scriptUrl.value is defined and scriptUrl.value | length %}\\nvar _paq = window._paq = window._paq || [];\\n{% if sendPageView.value %}\\n_paq.push([\'trackPageView\']);\\n{% endif %}\\n{% if sendPageView.value %}\\n_paq.push([\'enableLinkTracking\']);\\n{% endif %}\\n(function() {\\nvar u=\\\"{{ scriptUrl.value }}\\\";\\n_paq.push([\'setTrackerUrl\', u+\'matomo.php\']);\\n_paq.push([\'setSiteId\', {{ siteId.value }}]);\\nvar d=document, g=d.createElement(\'script\'), s=d.getElementsByTagName(\'script\')[0];\\ng.type=\'text\\/javascript\'; g.async=true; g.src=u+\'matomo.js\'; s.parentNode.insertBefore(g,s);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https:\\/\\/developer.matomo.org\\/guides\\/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Matomo PageView\",\"instructions\":\"Controls whether the Matomo script automatically sends a PageView when your pages are loaded. [Learn More](https:\\/\\/developer.matomo.org\\/api-reference\\/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"enableLinkTracking\":{\"title\":\"Enable Link Tracking\",\"instructions\":\"Install link tracking on all applicable link elements. [Learn More](https:\\/\\/developer.matomo.org\\/api-reference\\/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"scriptUrl\":{\"title\":\"Matomo Script URL\",\"instructions\":\"The URL to the Matomo tracking script. This will vary depending on whether you are using Matomo Cloud or Matomo On-Premise. [Learn More](https:\\/\\/developer.matomo.org\\/guides\\/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"matomo\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"plausible\":{\"name\":\"Plausible\",\"description\":\"Plausible is a lightweight and open-source website analytics tool. No cookies and fully compliant with GDPR, CCPA and PECR. [Learn More](https:\\/\\/plausible.io\\/)\",\"templatePath\":\"_frontend\\/scripts\\/plausibleAnalytics.twig\",\"templateString\":\"{% if siteDomain.value is defined and siteDomain.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-domain\\\", \\\"{{ siteDomain.value | raw }}\\\");\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteDomain\":{\"title\":\"Site Domain\",\"instructions\":\"Only enter the site domain, not the entire script code. [Learn More](https:\\/\\/plausible.io\\/docs\\/plausible-script)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Plausible Script URL\",\"instructions\":\"The URL to the Plausible tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/plausible.io\\/js\\/plausible.js\"}},\"dataLayer\":[],\"deprecated\":false,\"deprecationNotice\":\"\",\"discontinued\":false,\"include\":false,\"key\":\"plausible\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleAnalytics\":{\"name\":\"Google Analytics (old)\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https:\\/\\/www.google.com\\/analytics\\/analytics\\/)\",\"templatePath\":\"_frontend\\/scripts\\/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https:\\/\\/support.google.com\\/analytics\\/answer\\/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https:\\/\\/developers.google.com\\/analytics\\/devguides\\/collection\\/analyticsjs\\/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https:\\/\\/www.google-analytics.com\\/analytics.js\"}},\"dataLayer\":[],\"deprecated\":true,\"deprecationNotice\":\"Universal Analytics (which is what this script uses) is being [discontinued on July 1st, 2023](https:\\/\\/support.google.com\\/analytics\\/answer\\/11583528). You should use Google gtag.js or Google Tag Manager instead and transition to a new GA4 property.\",\"discontinued\":false,\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"issn\":null,\"dateModified\":null,\"associatedMedia\":null,\"publisherImprint\":null,\"pattern\":null,\"audio\":null,\"recordedAt\":null,\"hasPart\":null,\"awards\":null,\"encoding\":null,\"workTranslation\":null,\"releasedEvent\":null,\"workExample\":null,\"spatial\":null,\"accessModeSufficient\":null,\"award\":null,\"review\":null,\"interpretedAsClaim\":null,\"publisher\":null,\"exampleOfWork\":null,\"genre\":null,\"translationOfWork\":null,\"headline\":null,\"acquireLicensePage\":null,\"assesses\":null,\"creativeWorkStatus\":null,\"sdLicense\":null,\"educationalUse\":null,\"countryOfOrigin\":null,\"contentRating\":null,\"locationCreated\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"accessibilitySummary\":null,\"commentCount\":null,\"copyrightYear\":null,\"isBasedOnUrl\":null,\"license\":null,\"usageInfo\":null,\"publication\":null,\"timeRequired\":null,\"interactivityType\":null,\"publishingPrinciples\":null,\"contributor\":null,\"citation\":null,\"conditionsOfAccess\":null,\"learningResourceType\":null,\"correction\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"reviews\":null,\"isPartOf\":null,\"producer\":null,\"thumbnail\":null,\"accessMode\":null,\"editEIDR\":null,\"temporalCoverage\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"educationalAlignment\":null,\"funding\":null,\"material\":null,\"alternativeHeadline\":null,\"version\":null,\"isFamilyFriendly\":null,\"materialExtent\":null,\"discussionUrl\":null,\"size\":null,\"maintainer\":null,\"copyrightNotice\":null,\"comment\":null,\"offers\":null,\"text\":null,\"fileFormat\":null,\"encodings\":null,\"about\":null,\"audience\":null,\"keywords\":null,\"spatialCoverage\":null,\"sponsor\":null,\"accessibilityAPI\":null,\"sdPublisher\":null,\"contentLocation\":null,\"interactionStatistic\":null,\"encodingFormat\":null,\"archivedAt\":null,\"mainEntity\":null,\"datePublished\":null,\"isAccessibleForFree\":null,\"dateCreated\":null,\"teaches\":null,\"thumbnailUrl\":null,\"accountablePerson\":null,\"typicalAgeRange\":null,\"sdDatePublished\":null,\"funder\":null,\"expires\":null,\"aggregateRating\":null,\"temporal\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"provider\":null,\"abstract\":null,\"digitalSourceType\":null,\"position\":null,\"mentions\":null,\"sourceOrganization\":null,\"video\":null,\"editor\":null,\"creditText\":null,\"schemaVersion\":null,\"translator\":null,\"accessibilityHazard\":null,\"contentReferenceTime\":null,\"educationalLevel\":null,\"character\":null,\"isBasedOn\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"additionalType\":null,\"potentialAction\":{\"type\":\"SearchAction\",\"target\":{\"type\":\"EntryPoint\",\"urlTemplate\":\"{{ seomatic.site.siteLinksSearchTarget }}\"},\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"alternateName\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\"},\"identity\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.site.identity.computedType }}\",\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\",\"graph\":null,\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"memberOf\":null,\"foundingLocation\":\"{{ seomatic.site.identity.organizationFoundingLocation }}\",\"hasOfferCatalog\":null,\"awards\":null,\"alumni\":null,\"nonprofitStatus\":null,\"slogan\":null,\"owns\":null,\"award\":null,\"event\":null,\"makesOffer\":null,\"review\":null,\"hasPOS\":null,\"duns\":\"{{ seomatic.site.identity.organizationDuns }}\",\"brand\":null,\"knowsLanguage\":null,\"department\":null,\"knowsAbout\":null,\"foundingDate\":\"{{ seomatic.site.identity.organizationFoundingDate }}\",\"diversityPolicy\":null,\"leiCode\":null,\"publishingPrinciples\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\",\"width\":\"{{ seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\",\"height\":\"{{ seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\"},\"ownershipFundingInfo\":null,\"reviews\":null,\"isicV4\":null,\"telephone\":\"{{ seomatic.site.identity.genericTelephone }}\",\"location\":null,\"correctionsPolicy\":null,\"areaServed\":null,\"funding\":null,\"employee\":null,\"numberOfEmployees\":null,\"hasMerchantReturnPolicy\":null,\"iso6523Code\":null,\"taxID\":null,\"naics\":null,\"founders\":null,\"contactPoint\":null,\"serviceArea\":null,\"globalLocationNumber\":null,\"keywords\":null,\"email\":\"{{ seomatic.site.identity.genericEmail }}\",\"ethicsPolicy\":null,\"sponsor\":null,\"agentInteractionStatistic\":null,\"employees\":null,\"events\":null,\"interactionStatistic\":null,\"legalName\":null,\"vatID\":null,\"members\":null,\"funder\":null,\"aggregateRating\":null,\"hasCredential\":null,\"seeks\":null,\"subOrganization\":null,\"dissolutionDate\":null,\"contactPoints\":[],\"founder\":\"{{ seomatic.site.identity.organizationFounder }}\",\"unnamedSourcesPolicy\":null,\"parentOrganization\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{{ seomatic.site.identity.genericStreetAddress }}\",\"addressLocality\":\"{{ seomatic.site.identity.genericAddressLocality }}\",\"addressRegion\":\"{{ seomatic.site.identity.genericAddressRegion }}\",\"postalCode\":\"{{ seomatic.site.identity.genericPostalCode }}\",\"addressCountry\":\"{{ seomatic.site.identity.genericAddressCountry }}\"},\"faxNumber\":null,\"actionableFeedbackPolicy\":null,\"diversityStaffingReport\":null,\"hasCertification\":null,\"member\":null,\"name\":\"{{ seomatic.site.identity.genericName }}\",\"description\":\"{{ seomatic.site.identity.genericDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.site.identity.genericUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.site.identity.genericImage }}\",\"width\":\"{{ seomatic.site.identity.genericImageWidth }}\",\"height\":\"{{ seomatic.site.identity.genericImageHeight }}\"},\"additionalType\":null,\"potentialAction\":null,\"alternateName\":\"{{ seomatic.site.identity.genericAlternateName }}\",\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":null},\"creator\":{\"context\":\"http:\\/\\/schema.org\",\"type\":\"{{ seomatic.site.creator.computedType }}\",\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\",\"graph\":null,\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"memberOf\":null,\"foundingLocation\":\"{{ seomatic.site.creator.organizationFoundingLocation }}\",\"hasOfferCatalog\":null,\"awards\":null,\"alumni\":null,\"nonprofitStatus\":null,\"slogan\":null,\"owns\":null,\"award\":null,\"event\":null,\"makesOffer\":null,\"review\":null,\"hasPOS\":null,\"duns\":\"{{ seomatic.site.creator.organizationDuns }}\",\"brand\":null,\"knowsLanguage\":null,\"department\":null,\"knowsAbout\":null,\"foundingDate\":\"{{ seomatic.site.creator.organizationFoundingDate }}\",\"diversityPolicy\":null,\"leiCode\":null,\"publishingPrinciples\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\",\"width\":\"{{ seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\",\"height\":\"{{ seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\"},\"ownershipFundingInfo\":null,\"reviews\":null,\"isicV4\":null,\"telephone\":\"{{ seomatic.site.creator.genericTelephone }}\",\"location\":null,\"correctionsPolicy\":null,\"areaServed\":null,\"funding\":null,\"employee\":null,\"numberOfEmployees\":null,\"hasMerchantReturnPolicy\":null,\"iso6523Code\":null,\"taxID\":null,\"naics\":null,\"founders\":null,\"contactPoint\":null,\"serviceArea\":null,\"globalLocationNumber\":null,\"keywords\":null,\"email\":\"{{ seomatic.site.creator.genericEmail }}\",\"ethicsPolicy\":null,\"sponsor\":null,\"agentInteractionStatistic\":null,\"employees\":null,\"events\":null,\"interactionStatistic\":null,\"legalName\":null,\"vatID\":null,\"members\":null,\"funder\":null,\"aggregateRating\":null,\"hasCredential\":null,\"seeks\":null,\"subOrganization\":null,\"dissolutionDate\":null,\"contactPoints\":[],\"founder\":\"{{ seomatic.site.creator.organizationFounder }}\",\"unnamedSourcesPolicy\":null,\"parentOrganization\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{{ seomatic.site.creator.genericStreetAddress }}\",\"addressLocality\":\"{{ seomatic.site.creator.genericAddressLocality }}\",\"addressRegion\":\"{{ seomatic.site.creator.genericAddressRegion }}\",\"postalCode\":\"{{ seomatic.site.creator.genericPostalCode }}\",\"addressCountry\":\"{{ seomatic.site.creator.genericAddressCountry }}\"},\"faxNumber\":null,\"actionableFeedbackPolicy\":null,\"diversityStaffingReport\":null,\"hasCertification\":null,\"member\":null,\"name\":\"{{ seomatic.site.creator.genericName }}\",\"description\":\"{{ seomatic.site.creator.genericDescription }}\",\"subjectOf\":null,\"url\":\"{{ seomatic.site.creator.genericUrl }}\",\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.site.creator.genericImage }}\",\"width\":\"{{ seomatic.site.creator.genericImageWidth }}\",\"height\":\"{{ seomatic.site.creator.genericImageHeight }}\"},\"additionalType\":null,\"potentialAction\":null,\"alternateName\":\"{{ seomatic.site.creator.genericAlternateName }}\",\"disambiguatingDescription\":null,\"sameAs\":null,\"mainEntityOfPage\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"\\/* TEAM *\\/\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n\\/a\\\" }}\\nURL: {{ parseEnv(seomatic.site.creator.genericUrl ?? \\\"n\\/a\\\") }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n\\/a\\\" }}\\n\\n\\/* THANKS *\\/\\n\\nCraft CMS - https:\\/\\/craftcms.com\\nPixel & Tonic - https:\\/\\/pixelandtonic.com\\n\\n\\/* SITE *\\/\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 5, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend\\/pages\\/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }}\\n\\n{{ seomatic.helper.sitemapIndex() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n    # live - don\'t allow web crawlers to index cpresources\\/ or vendor\\/\\n\\n    User-agent: *\\n    Disallow: \\/cpresources\\/\\n    Disallow: \\/vendor\\/\\n    Disallow: \\/.env\\n    Disallow: \\/cache\\/\\n\\n{% case \\\"staging\\\" %}\\n\\n    # staging - disallow all\\n\\n    User-agent: *\\n    Disallow: \\/\\n\\n{% case \\\"local\\\" %}\\n\\n    # local - disallow all\\n\\n    User-agent: *\\n    Disallow: \\/\\n\\n{% default %}\\n\\n    # default - don\'t allow web crawlers to index cpresources\\/ or vendor\\/\\n\\n    User-agent: *\\n    Disallow: \\/cpresources\\/\\n    Disallow: \\/vendor\\/\\n    Disallow: \\/.env\\n    Disallow: \\/cache\\/\\n\\n{% endswitch %}\\n\\n# Disallow ChatGPT bot, as there\'s no benefit to allowing it to index your site\\nUser-agent: GPTBot\\nDisallow: \\/\\n\\n# Disallow Google Bard and Vertex AI bots, as there\'s no benefit to allowing it to index your site\\nUser-agent: Google-Extended\\nDisallow: \\/\\n\\n# Disallow Perplexity bot, as there\'s no benefit to allowing it to index your site\\nUser-agent: PerplexityBot\\nDisallow: \\/\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend\\/pages\\/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }}\\n# More info: https:\\/\\/support.google.com\\/admanager\\/answer\\/7441288?hl=en\\n{{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }},123,DIRECT\\n\",\"siteId\":null,\"include\":false,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend\\/pages\\/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"},\"security\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# security.txt file for {{ seomatic.helper.baseSiteUrl(\\\"\\/\\\") }} - more info: https:\\/\\/securitytxt.org\\/\\n\\n# (required) Contact email address for security issues\\nContact: mailto:user@example.com\\n\\n# (required) Expiration date for the security information herein\\nExpires: {{ date(\'+1 year\')|atom }}\\n\\n# (optional) OpenPGP key:\\nEncryption: {{ url(\'pgp-key.txt\') }}\\n\\n# (optional) Security policy page:\\nPolicy: {{ url(\'security-policy\') }}\\n\\n# (optional) Security acknowledgements page:\\nAcknowledgements: {{ url(\'hall-of-fame\') }}\\n\",\"siteId\":null,\"include\":false,\"handle\":\"security\",\"path\":\".well-known\\/security.txt\",\"template\":\"_frontend\\/pages\\/security.twig\",\"controller\":\"frontend-template\",\"action\":\"security\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":false,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":false,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
/*!40000 ALTER TABLE `seomatic_metabundles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ayorrnvzerqgsjmvnqdljaswqqhvznomqicn` (`uid`),
  KEY `idx_hbxqljarlcfsddbsbekealmgdflmotozbfgk` (`token`),
  KEY `idx_zxtrgieagrrhimkhancwrxxfvzexnkunwnuo` (`dateUpdated`),
  KEY `idx_wttgoochpxfsbmrfnrydivanjzjpwbhegrax` (`userId`),
  CONSTRAINT `fk_wsnryelkrutsrbiwnsfzvkfazrfieizzypja` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'zI3Nl8tr2rwtHPq2U3raLootgnnZ2qXnbkiJd9blx8xutQSSA1u7rQVpd62z2imKN1kCHZqPNKOq2TGHAEdFMLxtibXf8ES8_2ei','2024-04-07 10:55:50','2024-04-07 10:56:04','ddabdf37-e6db-4b2c-b5c2-0a824daf6423'),(3,1,'O-45nSZIOX0Bls1Or86ibDCMLMy57GeUumqTTYBCIZSBKpNNfiqHA_wpjxGsFEoMQdEBY1SMzDTyskX7ym9kFMXmCg_8yxnjpyWk','2024-04-07 23:24:05','2024-04-08 01:17:10','a2925444-0e99-4f1d-aba7-8787fb8c2f7e');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_krbjqvtaeyowfvvxgxbwyveqymdrqyrhxcdh` (`userId`,`message`),
  CONSTRAINT `fk_qejjfmnwicpnjsalgjehtpstpzuirzcuusfq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jacqvythgsldbhkydvdwlendzcdnfsixwiah` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Goodkit','2024-04-07 10:44:46','2024-04-08 01:00:30',NULL,'12b1eba7-eba9-4a9d-b427-47a4b9951704');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zrshdylarhiexvoobhpwlczaywqvoyewrlbr` (`dateDeleted`),
  KEY `idx_ravrzwjklktreqgntutkpitvbeecbbulvmgh` (`handle`),
  KEY `idx_pfsgulrbdknaxgxjnjbalqqokmhhodfryjfr` (`sortOrder`),
  KEY `fk_txdgzydbjaiohivrgpojgvqvwdicxtorakwt` (`groupId`),
  CONSTRAINT `fk_txdgzydbjaiohivrgpojgvqvwdicxtorakwt` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','Goodkit','default','en-US',1,'@web',1,'2024-04-07 10:44:46','2024-04-08 00:59:34',NULL,'6c8dfb37-039b-487a-8d0a-8339c35857d7');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fbhdtemifhnvaxpnrtbitirkgwaoxtfqycjy` (`structureId`,`elementId`),
  KEY `idx_dyzubesaycvffyoddzdnhgmqgiuqfogjjgnk` (`root`),
  KEY `idx_wbyyusnfgxkcybkfjjcjoemrwquzpaaiggzh` (`lft`),
  KEY `idx_gimvhwnlahfuinkielikhurzbfmdoeaihwrl` (`rgt`),
  KEY `idx_hoqmpoioipdzblviphpcgptyfmtvcwyabnas` (`level`),
  KEY `idx_kuovpglnfjmlnmfyzfioezzbrxuutkepwukv` (`elementId`),
  CONSTRAINT `fk_qbhymxjvjufmhedgsasbdjndqltsjbknqhoz` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ckbxvfhmxrmpejvtaolifdjlvyuiegellcct` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dkmjdntojjfqzynsawlnmfvdugfthxuectet` (`key`,`language`),
  KEY `idx_ykflnydeudkcdbnqnsyjvuvshhhkccobquml` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_umeqiwrshdvurgnyawujwboxpxathgiclmoa` (`name`),
  KEY `idx_gcpaqxqtkhlswkfloxmhobmgydrcnwtduhnm` (`handle`),
  KEY `idx_terwaxfoykigitbjoiqalfjhfbswivpzdnik` (`dateDeleted`),
  KEY `fk_ikfvtgxgzbzztyiqmplucqaaloaaflgxczaq` (`fieldLayoutId`),
  CONSTRAINT `fk_ikfvtgxgzbzztyiqmplucqaaloaaflgxczaq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gpuesozcuvbwvsszmobhrdtfpavufrpwymix` (`groupId`),
  CONSTRAINT `fk_eabtnsxvzrscfcwsmvmolfbjzuvrutklcpzl` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_epjmacudulfgnwdynvtwfawtvzdyycgwxvkq` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dhpdorolfguwsgwztvttyeecybxakudrhpql` (`token`),
  KEY `idx_kcnfjrltidduwqiqphpfrkicwdspsjsqjkzr` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nuvafvmstpzkhvfcbxqqfmboxrjwtahhqjwx` (`handle`),
  KEY `idx_lzquijunbgysrhbruxklfnzcuoakzeijsngq` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pzyrnosbrxmcdvoiyqalepiouqcwfwarilhg` (`groupId`,`userId`),
  KEY `idx_khttmjvrverlbuwaukrhlgsymkyqdwhdcxir` (`userId`),
  CONSTRAINT `fk_qvqayirlhcuoenxvkmnfbniaxyrdcumgmkwx` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zosmdvynxlvtkezagbggvvontnyukbrtshkk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vqeynxdaxkaubrllxrvspbxogjmalvlepdce` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kqivxkbblcducsqtjgqzwoawdpxongtfgqfj` (`permissionId`,`groupId`),
  KEY `idx_lqzapktpjypffndhjkwoszpbbfhuqzheswmh` (`groupId`),
  CONSTRAINT `fk_eqrhlgyakfthwhabxatwlfeqkgrpyhaairmo` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xrvvejkdemtfgsredlfhwpegfiwhezjjbkss` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ragacjnyjfgiefofqfxobcdpotftqardtlut` (`permissionId`,`userId`),
  KEY `idx_qkuwasngfqwguuaphalybrbwxebdrywbefsg` (`userId`),
  CONSTRAINT `fk_dtfpuwxpinppacipwzdqamfjqevdwghsshcy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qtrgfhoohcmrzidihjpggdwwioeabgzqspdk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_cdybhkahyhxbgugpdwzsvvwsymtxtnpvxndq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"locale\": null, \"language\": \"en-US\", \"useShapes\": false, \"weekStartDay\": \"1\", \"underlineLinks\": false, \"disableAutofocus\": \"\", \"profileTemplates\": false, \"showFieldHandles\": true, \"showExceptionView\": false, \"alwaysShowFocusRings\": false, \"notificationDuration\": \"5000\", \"enableDebugToolbarForCp\": false, \"enableDebugToolbarForSite\": false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vlnronpwiigjssuwnlqobdwsrmvnvqxnhask` (`active`),
  KEY `idx_aabtlfpnflaaxtpfkwldmqibflzjtvnntitm` (`locked`),
  KEY `idx_jbcdgcswnsfaofsvfnoaqfjioeoclnshjqxq` (`pending`),
  KEY `idx_cbvbmpsbfmbmwyzinpycucqzbtazfpuezbpe` (`suspended`),
  KEY `idx_nftpgyzsmnoagewbddddkrvzbifrliovejao` (`verificationCode`),
  KEY `idx_mufgxuqwlhaynukklhtkrmgwdonjxiedwtxb` (`email`),
  KEY `idx_opmxqkxnivwnykxhigvngxjolaawxmthoqui` (`username`),
  KEY `fk_hlxrdaygxdsbghnyufdifetjupmfxubkljiv` (`photoId`),
  CONSTRAINT `fk_hlxrdaygxdsbghnyufdifetjupmfxubkljiv` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ykebthnrcbemayupxuwliawaowcaoccmibmd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin_kit',NULL,NULL,NULL,'anuar@hey.com','$2y$13$wZ5UiKoFfQL49TQDLzpQP.LGN6jLN2XSbkLIApiPJdKATnst46XOO','2024-04-07 23:24:05',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-04-07 10:44:47','2024-04-07 10:44:47','2024-04-07 23:24:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wcgrfubdukybhnciifidxlwegpzxuslmvzfo` (`name`,`parentId`,`volumeId`),
  KEY `idx_xjpulydgmlyzmtyvjvtewiecdvgwwezuxuht` (`parentId`),
  KEY `idx_sayomjovkfxmensuodkbkfcugjelinpianoq` (`volumeId`),
  CONSTRAINT `fk_srbwigbjvnhpdjewbmoqbzauzodsodgdyvvd` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wroeawcloacykbwrmpqztxzqcbvelejmyavs` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images',NULL,'2024-04-07 10:59:51','2024-04-07 11:01:12','8cb5ca71-eccf-4ff1-b6e8-301da80778a3'),(2,NULL,2,'Videos','','2024-04-07 11:02:25','2024-04-07 11:02:25','b2e028e6-d6b0-4f9e-8952-6721b4f3edfd'),(3,NULL,NULL,'Temporary Uploads',NULL,'2024-04-08 01:05:41','2024-04-08 01:05:41','2e885cf3-2f01-47d7-ac17-dda64fb0c490'),(4,3,NULL,'user_1','user_1/','2024-04-08 01:05:41','2024-04-08 01:05:41','b3aa1103-843d-476b-a467-2e1b2bc4c3ec');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kvmuajpdlndgfqhdqbcqejfkhcviofurbwdt` (`name`),
  KEY `idx_uafhtszwlscemnuzpzwwpgakhmrllvsjvrdr` (`handle`),
  KEY `idx_yhtfhmqkelnrfwfeqsztsvvpszpbdocpurfn` (`fieldLayoutId`),
  KEY `idx_ekghdywujnesxptdvmfmtydidoqzmfmkyhje` (`dateDeleted`),
  CONSTRAINT `fk_rrpvzdsddclflcqzepcsvadbxlapidxwpzrv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,1,'Images','images','mediaImages','','','','site',NULL,'none',NULL,1,'2024-04-07 10:59:51','2024-04-07 11:01:12',NULL,'db778210-0abd-4ebf-a5a5-e90e9735dfd6'),(2,2,'Videos','videos','mediaVideos','','','','site',NULL,'none',NULL,2,'2024-04-07 11:02:25','2024-04-07 11:02:25',NULL,'a23bbdd9-a1f0-45c6-abe2-23554ce14258');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_caaocsgwyezeluphkwnmwfvsmlmxuszgecwd` (`userId`),
  CONSTRAINT `fk_caaocsgwyezeluphkwnmwfvsmlmxuszgecwd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
INSERT INTO `webauthn` VALUES (1,1,'z0r9tXdxkz12cUGVRV3DOaaFyqM','{\"publicKeyCredentialId\":\"z0r9tXdxkz12cUGVRV3DOaaFyqM\",\"type\":\"public-key\",\"transports\":[\"hybrid\",\"internal\"],\"attestationType\":\"none\",\"trustPath\":{\"type\":\"Webauthn\\\\TrustPath\\\\EmptyTrustPath\"},\"aaguid\":\"fbfc3007-154e-4ecc-8c0b-6e020557d7bd\",\"credentialPublicKey\":\"pQECAyYgASFYILZnKg-gsm6I5fgQwfpMF3vFu-qPUfjRxR0h9VK0OPvKIlggduXLM7bp5I3UyDwY6ay_tx8cpQUGrdaksJQ0N8vXUXY\",\"userHandle\":\"MDE5MzVjYzQtMzc3OC00Yjk5LThhOTQtMzNjYzQ0ZDc3MjM3\",\"counter\":0,\"otherUI\":null,\"backupEligible\":true,\"backupStatus\":true,\"uvInitialized\":null}','Chrome on Mac','2024-04-07 23:24:05','2024-04-07 10:56:17','2024-04-07 23:24:05','9aa931cc-9f3a-464d-9de7-dfb488b2a11a');
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xtdwfkhymhyrxjbypginjzrbidtpyvzoykkb` (`userId`),
  CONSTRAINT `fk_kdgdfedntxbqjwrxnvrfajffhlqwifqnmcau` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-04-07 10:55:50','2024-04-07 10:55:50','2c08ef0b-18d1-4391-bafa-25f8b6577c7d'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-04-07 10:55:50','2024-04-07 10:55:50','5cd10632-a829-4166-a566-472964ccfb30'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-04-07 10:55:50','2024-04-07 10:55:50','ffb1831d-4bb7-4546-b3b7-70e41394173d'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-04-07 10:55:50','2024-04-07 10:55:50','e329cba7-1e57-45b5-85ed-d01eaab48d93');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-08  1:17:14
